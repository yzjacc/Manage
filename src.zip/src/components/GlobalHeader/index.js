import GlobalHeader from './GlobalHeader'
export default GlobalHeader
