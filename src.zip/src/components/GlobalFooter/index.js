import GlobalFooter from './GlobalFooter'
export default GlobalFooter
