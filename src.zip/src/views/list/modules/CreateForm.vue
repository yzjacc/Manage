<template>
  <a-modal
    title="新建项目"
    :width="640"
    :visible="visible"
    :confirmLoading="confirmLoading"
    @ok="handleSubmit"
    @cancel="handleCancel"
  >
    <a-spin :spinning="confirmLoading">
      <a-form :form="form">
        <a-form-item
          label="项目信息输入"
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
        >
         <a-input placeholder="请输入项目名称"/>
         <a-input placeholder="请输入项目编号"/>
         <a-input placeholder="请输入项目管理员"/>
         <a-input placeholder="请输入项目归属"/>
         <a-select v-model="one" placeholder="请输入项目有无分包">
            <a-select-option value="0">有</a-select-option>
            <a-select-option value="1">无</a-select-option>
          </a-select>
          <a-select v-model="two" placeholder="请输入项目状态">
            <a-select-option value="0">全部</a-select-option>
            <a-select-option value="1">关闭</a-select-option>
            <a-select-option value="2">运行中</a-select-option>
          </a-select>
          <a-date-picker style="width: 100%" placeholder="请输入上线日期"/>
        </a-form-item>
      </a-form>
    </a-spin>
  </a-modal>
</template>

<script>
export default {
  data () {
    return {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 13 }
      },
      visible: false,
      confirmLoading: false,

      form: this.$form.createForm(this)
    }
  },
  methods: {
    add () {
      this.visible = true
    },
    handleSubmit () {
      const { form: { validateFields } } = this
      this.confirmLoading = true
      validateFields((errors, values) => {
        if (!errors) {
          console.log('values', values)
          setTimeout(() => {
            this.visible = false
            this.confirmLoading = false
            this.$emit('ok', values)
          }, 1500)
        } else {
          this.confirmLoading = false
        }
      })
    },
    handleCancel () {
      this.visible = false
    }
  }
}
</script>
